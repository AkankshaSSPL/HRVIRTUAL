export type UUID = string;

