"""employee agent salary support

Revision ID: 20260528_0005
Revises: 20260528_0004
Create Date: 2026-05-28
"""

from alembic import op
import sqlalchemy as sa


revision = "20260528_0005"
down_revision = "20260528_0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("employees", sa.Column("current_salary", sa.Numeric(14, 2), nullable=True))


def downgrade() -> None:
    op.drop_column("employees", "current_salary")
