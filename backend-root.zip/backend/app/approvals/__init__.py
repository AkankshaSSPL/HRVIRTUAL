"""Approval domain package."""

